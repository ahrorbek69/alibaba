import React from 'react'
import RequestMultiple from '../../components/request-multiple/RequestMultiple'

const Home = () => {
  return (
    <div>
      
        <RequestMultiple />

    </div>
  )
}

export default Home